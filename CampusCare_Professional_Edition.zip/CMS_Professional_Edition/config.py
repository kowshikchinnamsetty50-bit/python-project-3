"""Central configuration with environment-variable overrides."""
from __future__ import annotations
import json
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = Path(os.getenv("CMS_CONFIG_FILE", BASE_DIR / "config.json"))
DEFAULTS = {
    "database_path": str(BASE_DIR / "data" / "complaints.db"),
    "log_path": str(BASE_DIR / "logs" / "complaint_system.log"),
    "page_size": 10,
    "app_name": "CampusCare Complaint Management System",
    "enable_duplicate_warning": True,
}

def load_config() -> dict:
    config = DEFAULTS.copy()
    if CONFIG_FILE.exists():
        try:
            with CONFIG_FILE.open("r", encoding="utf-8") as handle:
                user_config = json.load(handle)
            if not isinstance(user_config, dict):
                raise ValueError("config.json must contain a JSON object")
            config.update({k: v for k, v in user_config.items() if k in DEFAULTS})
        except (OSError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Unable to read configuration: {exc}") from exc
    # Environment variables take precedence over config.json.
    mapping = {
        "CMS_DATABASE_PATH": "database_path",
        "CMS_LOG_PATH": "log_path",
        "CMS_PAGE_SIZE": "page_size",
        "CMS_APP_NAME": "app_name",
    }
    for env_key, config_key in mapping.items():
        if env_key in os.environ:
            config[config_key] = os.environ[env_key]
    config["page_size"] = int(config["page_size"])
    if not 1 <= config["page_size"] <= 500:
        raise ValueError("page_size must be between 1 and 500")
    return config
