"""Business rules, validation, complaint workflows and reporting."""
from datetime import date, timedelta
import csv
import json
from pathlib import Path

CATEGORIES = ['Academic','Infrastructure','Hostel','Transport','Canteen','IT Support','Other']
STATUSES = ['Open','In Progress','Resolved','Rejected']
PRIORITY_DAYS = {'High': 2, 'Medium': 4, 'Low': 7}

class ValidationError(ValueError): pass

class ComplaintService:
    def __init__(self, repository): self.repo = repository

    @staticmethod
    def validate(payload):
        required = ('name','contact','title','description','category','priority')
        for key in required:
            if not str(payload.get(key, '')).strip(): raise ValidationError(f'{key} is required')
        limits = {'name':100,'contact':100,'title':120,'description':2000}
        for key, limit in limits.items():
            if len(str(payload[key]).strip()) > limit: raise ValidationError(f'{key} must be at most {limit} characters')
        if payload['category'] not in CATEGORIES: raise ValidationError('Invalid category')
        if payload['priority'] not in PRIORITY_DAYS: raise ValidationError('Invalid priority')

    def create(self, payload, today=None):
        self.validate(payload); today = today or date.today()
        number = self.repo.count() + 1
        while self.repo.get(f'CMP{number:04d}', include_deleted=True): number += 1
        record = {k:str(payload[k]).strip() for k in ('name','contact','title','description','category','priority')}
        record.update(id=f'CMP{number:04d}', status='Open', created_date=today.isoformat(), updated_date=today.isoformat(),
                      due_date=(today + timedelta(days=PRIORITY_DAYS[payload['priority']])).isoformat(), resolution_note='')
        self.repo.add(record); return record

    def change_status(self, complaint_id, status, remark='', today=None):
        if status not in STATUSES: raise ValidationError('Invalid status')
        today = today or date.today()
        if not self.repo.update(complaint_id, {'status':status,'updated_date':today.isoformat()}, remark):
            raise ValidationError('Complaint not found or archived')

    def soft_delete(self, complaint_id, today=None):
        if not self.repo.soft_delete(complaint_id, (today or date.today()).isoformat()):
            raise ValidationError('Complaint not found or already archived')

    def restore(self, complaint_id):
        if not self.repo.restore(complaint_id): raise ValidationError('Archived complaint not found')

    def overdue(self, today=None):
        today = today or date.today()
        return [c for c in self.repo.list() if c['status'] in ('Open','In Progress') and c['due_date'] < today.isoformat()]

    def summary(self):
        records = self.repo.list()
        return {'total':len(records), 'statuses':{s:sum(c['status']==s for c in records) for s in STATUSES},
                'categories':{c:sum(x['category']==c for x in records) for c in CATEGORIES},
                'archived':self.repo.count(include_deleted=True)-len(records)}

    def export_json(self, path):
        data = self.repo.list(include_deleted=True)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=2, ensure_ascii=False)
        return len(data)

    def import_csv(self, path):
        added, errors = 0, []
        with open(path, newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            required = {'name','contact','title','description','category','priority'}
            if not reader.fieldnames or not required.issubset(reader.fieldnames): raise ValidationError('CSV requires columns: ' + ', '.join(sorted(required)))
            for row_no, row in enumerate(reader, 2):
                try: self.create(row); added += 1
                except (ValidationError, KeyError) as exc: errors.append(f'Row {row_no}: {exc}')
        return added, errors
