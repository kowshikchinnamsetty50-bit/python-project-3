"""SQLite repository: persistence, pagination, history and soft deletion."""
from __future__ import annotations
import sqlite3
from pathlib import Path
from contextlib import contextmanager

class ComplaintRepository:
    def __init__(self, db_path="complaints.db"):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _initialize(self):
        with self._connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS complaints (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, contact TEXT NOT NULL,
                title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL,
                priority TEXT NOT NULL, status TEXT NOT NULL, created_date TEXT NOT NULL,
                due_date TEXT NOT NULL, updated_date TEXT NOT NULL, resolution_note TEXT DEFAULT '',
                is_deleted INTEGER NOT NULL DEFAULT 0 CHECK(is_deleted IN (0,1)), deleted_at TEXT
            )""")
            # Safe migration for databases created by earlier editions.
            columns = {row[1] for row in con.execute("PRAGMA table_info(complaints)")}
            if "is_deleted" not in columns:
                con.execute("ALTER TABLE complaints ADD COLUMN is_deleted INTEGER NOT NULL DEFAULT 0")
            if "deleted_at" not in columns:
                con.execute("ALTER TABLE complaints ADD COLUMN deleted_at TEXT")
            con.execute("""CREATE TABLE IF NOT EXISTS complaint_history (
                history_id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_id TEXT NOT NULL, old_status TEXT, new_status TEXT NOT NULL,
                changed_at TEXT NOT NULL, remark TEXT DEFAULT '',
                FOREIGN KEY(complaint_id) REFERENCES complaints(id) ON DELETE RESTRICT
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status, is_deleted)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_complaints_created ON complaints(created_date)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_history_complaint ON complaint_history(complaint_id)")

    def add(self, complaint):
        fields = ('id','name','contact','title','description','category','priority','status','created_date','due_date','updated_date','resolution_note')
        with self._connect() as con:
            values = tuple(complaint.get(k, '') for k in fields)
            con.execute(f"INSERT INTO complaints ({','.join(fields)}) VALUES ({','.join('?' for _ in fields)})", values)
            con.execute("INSERT INTO complaint_history(complaint_id,old_status,new_status,changed_at,remark) VALUES(?,?,?,?,?)",
                        (complaint['id'], None, complaint['status'], complaint['created_date'], 'Complaint registered'))

    def update(self, complaint_id, values, remark=''):
        allowed = {'category','priority','status','updated_date','resolution_note','due_date'}
        values = {k: v for k, v in values.items() if k in allowed}
        with self._connect() as con:
            row = con.execute('SELECT status FROM complaints WHERE id=? AND is_deleted=0', (complaint_id,)).fetchone()
            if row is None:
                return False
            old_status = row['status']
            if values:
                clause = ', '.join(f'{k}=?' for k in values)
                con.execute(f'UPDATE complaints SET {clause} WHERE id=? AND is_deleted=0', (*values.values(), complaint_id))
            new_status = values.get('status', old_status)
            if new_status != old_status:
                con.execute('INSERT INTO complaint_history(complaint_id,old_status,new_status,changed_at,remark) VALUES(?,?,?,?,?)',
                            (complaint_id, old_status, new_status, values.get('updated_date',''), remark))
            return True

    def get(self, complaint_id, include_deleted=False):
        sql = 'SELECT * FROM complaints WHERE id=?'
        if not include_deleted: sql += ' AND is_deleted=0'
        with self._connect() as con:
            row = con.execute(sql, (complaint_id,)).fetchone()
            return dict(row) if row else None

    def list(self, limit=None, offset=0, include_deleted=False):
        sql = 'SELECT * FROM complaints'
        if not include_deleted: sql += ' WHERE is_deleted=0'
        sql += ' ORDER BY created_date DESC, id DESC'
        if limit is not None: sql += ' LIMIT ? OFFSET ?'
        with self._connect() as con:
            rows = con.execute(sql, (limit, offset)).fetchall() if limit is not None else con.execute(sql).fetchall()
            return [dict(r) for r in rows]

    def count(self, include_deleted=False):
        sql = 'SELECT COUNT(*) FROM complaints' + ('' if include_deleted else ' WHERE is_deleted=0')
        with self._connect() as con: return con.execute(sql).fetchone()[0]

    def history(self, complaint_id):
        with self._connect() as con:
            return [dict(r) for r in con.execute('SELECT * FROM complaint_history WHERE complaint_id=? ORDER BY history_id', (complaint_id,))]

    def search(self, keyword='', category='', status='', limit=None, offset=0):
        sql = 'SELECT * FROM complaints WHERE is_deleted=0'
        args = []
        if keyword:
            sql += ' AND (id LIKE ? OR name LIKE ? OR title LIKE ? OR description LIKE ?)'; args.extend([f'%{keyword}%']*4)
        if category: sql += ' AND category=?'; args.append(category)
        if status: sql += ' AND status=?'; args.append(status)
        sql += ' ORDER BY created_date DESC, id DESC'
        if limit is not None: sql += ' LIMIT ? OFFSET ?'; args.extend([limit, offset])
        with self._connect() as con: return [dict(r) for r in con.execute(sql, args)]

    def soft_delete(self, complaint_id, deleted_at):
        with self._connect() as con:
            cur = con.execute('UPDATE complaints SET is_deleted=1, deleted_at=? WHERE id=? AND is_deleted=0', (deleted_at, complaint_id))
            return cur.rowcount == 1

    def restore(self, complaint_id):
        with self._connect() as con:
            cur = con.execute('UPDATE complaints SET is_deleted=0, deleted_at=NULL WHERE id=? AND is_deleted=1', (complaint_id,))
            return cur.rowcount == 1

    def deleted(self):
        with self._connect() as con:
            return [dict(r) for r in con.execute('SELECT * FROM complaints WHERE is_deleted=1 ORDER BY deleted_at DESC')]
