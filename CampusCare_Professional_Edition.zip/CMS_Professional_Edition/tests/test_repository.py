"""Direct repository-layer tests, separate from service tests."""
import tempfile
import unittest
from pathlib import Path
from storage import ComplaintRepository

class RepositoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.repo=ComplaintRepository(Path(self.tmp.name)/'repo.db')
        self.record={'id':'CMP0001','name':'A Student','contact':'a@example.com','title':'Wi-Fi issue','description':'Slow network','category':'IT Support','priority':'Medium','status':'Open','created_date':'2026-01-01','due_date':'2026-01-05','updated_date':'2026-01-01','resolution_note':''}
    def tearDown(self): self.tmp.cleanup()
    def test_add_get_and_count(self):
        self.repo.add(self.record); self.assertEqual(self.repo.get('CMP0001')['title'],'Wi-Fi issue'); self.assertEqual(self.repo.count(),1)
    def test_search_uses_filters(self):
        self.repo.add(self.record); self.assertEqual(len(self.repo.search(keyword='network',category='IT Support',status='Open')),1)
        self.assertEqual(len(self.repo.search(status='Resolved')),0)
    def test_update_status_creates_history(self):
        self.repo.add(self.record); self.assertTrue(self.repo.update('CMP0001',{'status':'Resolved','updated_date':'2026-01-02'},'Fixed'))
        self.assertEqual(self.repo.history('CMP0001')[-1]['remark'],'Fixed')
    def test_soft_delete_hides_but_preserves_record_and_history(self):
        self.repo.add(self.record); self.assertTrue(self.repo.soft_delete('CMP0001','2026-01-03'))
        self.assertIsNone(self.repo.get('CMP0001')); self.assertIsNotNone(self.repo.get('CMP0001',include_deleted=True))
        self.assertEqual(len(self.repo.history('CMP0001')),1); self.assertTrue(self.repo.restore('CMP0001'))
    def test_pagination_and_count_exclude_archived(self):
        for i in range(1,4):
            r=self.record.copy(); r['id']=f'CMP{i:04d}'; self.repo.add(r)
        self.repo.soft_delete('CMP0002','2026-01-04')
        self.assertEqual(self.repo.count(),2); self.assertEqual(len(self.repo.list(limit=1,offset=0)),1)

if __name__=='__main__': unittest.main()
