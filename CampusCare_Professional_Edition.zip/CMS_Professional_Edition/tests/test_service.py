import tempfile
import unittest
from datetime import date
from pathlib import Path
from storage import ComplaintRepository
from service import ComplaintService, ValidationError

class ComplaintServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.repo=ComplaintRepository(Path(self.tmp.name)/'test.db'); self.svc=ComplaintService(self.repo)
        self.payload={'name':'Test Student','contact':'test@example.com','title':'Fan broken','description':'Fan is not working','category':'Hostel','priority':'High'}
    def tearDown(self): self.tmp.cleanup()
    def test_create_generates_id_and_priority_due_date(self):
        c=self.svc.create(self.payload,today=date(2026,1,1)); self.assertEqual(c['id'],'CMP0001'); self.assertEqual(c['due_date'],'2026-01-03')
    def test_required_field_validation(self):
        with self.assertRaises(ValidationError): self.svc.create(dict(self.payload,name=''))
    def test_status_history_is_recorded(self):
        c=self.svc.create(self.payload,today=date(2026,1,1)); self.svc.change_status(c['id'],'In Progress','Assigned',today=date(2026,1,2))
        history=self.repo.history(c['id']); self.assertEqual(len(history),2); self.assertEqual(history[-1]['new_status'],'In Progress')
    def test_overdue_excludes_resolved(self):
        c=self.svc.create(self.payload,today=date(2026,1,1)); self.assertEqual(len(self.svc.overdue(today=date(2026,1,5))),1)
        self.svc.change_status(c['id'],'Resolved',today=date(2026,1,5)); self.assertEqual(len(self.svc.overdue(today=date(2026,1,6))),0)
    def test_pagination(self):
        for _ in range(12): self.svc.create(self.payload)
        self.assertEqual(len(self.repo.list(limit=10,offset=0)),10); self.assertEqual(len(self.repo.list(limit=10,offset=10)),2)
    def test_soft_delete_retains_history_and_can_restore(self):
        c=self.svc.create(self.payload,today=date(2026,1,1)); self.svc.change_status(c['id'],'In Progress','Assigned',today=date(2026,1,2))
        self.svc.soft_delete(c['id'],today=date(2026,1,3)); self.assertIsNone(self.repo.get(c['id']))
        self.assertEqual(len(self.repo.history(c['id'])),2); self.svc.restore(c['id']); self.assertIsNotNone(self.repo.get(c['id']))
    def test_json_backup_includes_archived_records(self):
        import json
        c=self.svc.create(self.payload); self.svc.soft_delete(c['id'])
        target=Path(self.tmp.name)/'backup.json'; self.assertEqual(self.svc.export_json(target),1)
        self.assertEqual(json.loads(target.read_text())[0]['is_deleted'],1)

if __name__=='__main__': unittest.main()
