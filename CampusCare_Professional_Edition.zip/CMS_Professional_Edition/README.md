# CampusCare — Complaint Management System (Professional Edition)

A modular Python 3.10+ campus complaint tracker using SQLite, a repository/service architecture, audit history, soft deletion, configurable paths and automated tests.

## Run
```bash
python complaint_management.py
```

## Tests
```bash
python -m unittest discover -s tests -v
```

## Project structure
- `complaint_management.py` — CLI / presentation layer.
- `service.py` — validation, workflows, due dates, summary and JSON backup.
- `storage.py` — SQLite repository, indexed queries, pagination and history.
- `config.py` + `config.json` — centralized settings; environment variables override file values.
- `tests/` — service and direct repository unit tests.
- `data/` and `logs/` — created automatically when the app runs.

## Improvements addressing Evaluation Attempt #2
- Centralized database/log paths and page size in `config.json`.
- Environment overrides: `CMS_DATABASE_PATH`, `CMS_LOG_PATH`, `CMS_PAGE_SIZE`, `CMS_APP_NAME`.
- Direct repository tests in addition to service tests.
- Soft delete and restore preserve complaint history; archived items are hidden from active views.
- More resilient integer prompts for category, priority, page and status selection.
- JSON backup export complements CSV import/export and SQLite persistence.
- SQLite indexes and WAL mode support common query workloads.

## Core features
Unique complaint IDs; seven categories; High/Medium/Low due dates (2/4/7 days); status tracking; remarks and timestamped history; keyword/category/status filters; pagination; overdue alerts; summaries; CSV import; CSV/TXT/Markdown reports; JSON backup; archive and restore.

## Configuration precedence
Defaults → `config.json` → environment variables. Example variables are in `.env.example`. Python's standard library is used; `.env.example` is a reference file and is not automatically loaded.

## Important
This is a local academic demonstration application, not a production deployment. Add authentication, authorization, encrypted backups and deployment hardening before handling real personal or sensitive complaints.
