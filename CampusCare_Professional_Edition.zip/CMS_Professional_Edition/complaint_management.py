"""CampusCare Complaint Management System - command-line interface."""
import csv
import logging
from pathlib import Path
from config import load_config
from storage import ComplaintRepository
from service import ComplaintService, CATEGORIES, STATUSES, ValidationError


def configure_logging(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=path, level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(name)s: %(message)s')


def ask_number(prompt, minimum, maximum, default=None):
    """Repeat until a valid integer in range is entered; Ctrl+C is handled by main."""
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None: return default
        try: value = int(raw)
        except ValueError:
            print('Please enter a whole number.'); continue
        if minimum <= value <= maximum: return value
        print(f'Enter a number from {minimum} to {maximum}.')


def show(c):
    print(f"\n{c['id']} | {c['title']} | {c['category']} | {c['priority']} | {c['status']}")
    print(f"Name: {c['name']} | Due: {c['due_date']}\n{c['description']}")
    if c.get('resolution_note'): print('Resolution:', c['resolution_note'])


def main():
    cfg = load_config(); configure_logging(cfg['log_path'])
    repo = ComplaintRepository(cfg['database_path']); service = ComplaintService(repo)
    while True:
        print(f"\n{'='*58}\n {cfg['app_name'].upper()}\n{'='*58}")
        print('1 Register   2 View pages   3 Update status   4 Search/filter')
        print('5 Summary    6 Overdue      7 Export reports  8 Import CSV')
        print('9 History    10 Archive     11 Restore         12 JSON backup')
        print('0 Exit')
        try:
            choice = input('Choose an option: ').strip()
            if choice == '1':
                p = {k:input(f'{k.title()}: ').strip() for k in ('name','contact','title','description')}
                for i, value in enumerate(CATEGORIES,1): print(i, value)
                p['category'] = CATEGORIES[ask_number('Category number: ',1,len(CATEGORIES))-1]
                p['priority'] = ['High','Medium','Low'][ask_number('Priority (1 High, 2 Medium, 3 Low): ',1,3)-1]
                c = service.create(p); logging.info('Created %s',c['id']); print('Created:',c['id'])
            elif choice == '2':
                page = ask_number('Page number [1]: ',1,10**6,1); size = cfg['page_size']
                records = repo.list(size,(page-1)*size)
                print(f"Total active: {repo.count()} | Page {page} | Page size {size}")
                for c in records: show(c)
                if not records: print('No records on this page.')
            elif choice == '3':
                cid=input('Complaint ID: ').strip().upper(); c=repo.get(cid)
                if not c: print('Active complaint not found.'); continue
                for i, status in enumerate(STATUSES,1): print(i,status)
                status=STATUSES[ask_number('New status number: ',1,len(STATUSES))-1]
                remark=input('Remark (optional): ').strip()
                service.change_status(cid,status,remark); logging.info('Status changed: %s -> %s',cid,status); print('Updated.')
            elif choice == '4':
                keyword=input('Keyword (optional): ').strip(); cat=input('Category (exact or blank): ').strip(); status=input('Status (exact or blank): ').strip()
                for c in repo.search(keyword,cat,status): show(c)
            elif choice == '5': print(service.summary())
            elif choice == '6':
                items=service.overdue(); print('Overdue unresolved complaints:',len(items))
                for c in items: show(c)
            elif choice == '7':
                records=repo.list(); fields=['id','name','contact','title','description','category','priority','status','created_date','due_date','updated_date','resolution_note']
                with open('complaints_report.csv','w',newline='',encoding='utf-8') as f:
                    writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader(); writer.writerows(records)
                counts=service.summary()['statuses']
                lines=['# CampusCare Complaint Report','',f"Total active complaints: {len(records)}",'', '| Status | Count |','|---|---:|']
                lines += [f'| {status} | {count} |' for status,count in counts.items()]
                Path('complaints_report.md').write_text('\n'.join(lines),encoding='utf-8')
                Path('complaints_report.txt').write_text('\n'.join(lines),encoding='utf-8')
                print('Exported CSV, Markdown and TXT reports.')
            elif choice == '8':
                n, errors=service.import_csv(input('CSV path: ').strip()); print('Imported:',n)
                for error in errors: print(error)
            elif choice == '9':
                cid=input('Complaint ID: ').strip().upper()
                for item in repo.history(cid): print(item)
            elif choice == '10':
                cid=input('Complaint ID to archive: ').strip().upper(); service.soft_delete(cid)
                logging.info('Archived %s',cid); print('Archived. History has been retained.')
            elif choice == '11':
                archived=repo.deleted()
                for item in archived: print(item['id'], '-', item['title'])
                cid=input('Complaint ID to restore: ').strip().upper(); service.restore(cid)
                logging.info('Restored %s',cid); print('Restored.')
            elif choice == '12':
                count=service.export_json('backups/complaints_backup.json'); print(f'JSON backup created: {count} records.')
            elif choice == '0': print('Thank you. Goodbye!'); break
            else: print('Invalid menu option. Choose 0–12.')
        except (ValueError, OSError, ValidationError) as exc:
            print('Could not complete operation:',exc); logging.warning('Operation rejected: %s',exc)
        except KeyboardInterrupt:
            print('\nOperation cancelled. Returning to menu.')
        except Exception:
            logging.exception('Unexpected application error')
            print('An unexpected error occurred. Details were saved to the application log.')

if __name__ == '__main__': main()
